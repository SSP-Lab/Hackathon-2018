#pip install pandas --proxy proxy-rie.http.insee.fr:8080
#pip install re --proxy proxy-rie.http.insee.fr:8080

http_proxy  = "proxy-rie.http.insee.fr:8080"
https_proxy = "proxy-rie.http.insee.fr:8080"
ftp_proxy   = "proxy-rie.http.insee.fr:8080"

proxyDict = { 
              "http"  : http_proxy, 
              "https" : https_proxy, 
              "ftp"   : ftp_proxy
            }

import pandas as pd
import requests
from pprint import pprint
import json
import re


url = "https://prototype.api-sirene.insee.fr/ws"

def build_siret_query (com,act):
    siret_query = "/siret/?q=LibelleCommuneEtablissement:{} AND periode(ActivitePrincipaleEtablissement:{})&nombre=5000"
    print(url+siret_query.format(com,act))
    return url + siret_query.format(com,act)

def search_siret_rs(com,act):
    return requests.get(build_siret_query(com,act))

def requete_api(com,act) :
    
    activite = str(act)[:1]
    requete = search_siret_rs(com,activite+"*")    
    reponse = requete.json()

    # Chargement du fichier au format json
    #pprint(reponse)

    etab = reponse['Etablissements']

    table = [{'siret' : etab[i]["Siren"]+etab[i]["Nic"],
          'PrenNom' : re.sub('None','',str(etab[i]['UniteLegale']["PrenomUsuel"]))+" "+re.sub('None','',str(etab[i]['UniteLegale']["Nom"])),
          'ActSiege' : etab[i]['UniteLegale']["LibelleActivite"],
         'CompAdr' : etab[i]['Adresse']["ComplementAdresseEtablissement"],
         'Numvoie' : etab[i]['Adresse']["NumeroVoieEtablissement"],
         'IndRep' : etab[i]['Adresse']["IndiceRepetitionEtablissement"],
         'TypeVoie' : etab[i]['Adresse']["TypeVoieEtablissement"],
         'LibVoie' : etab[i]['Adresse']["LibelleVoieEtablissement"],
        'LibComm' : etab[i]['Adresse']["LibelleCommuneEtablissement"],
        'denom' : etab[i]['UniteLegale']["Denomination"],
        'enseigne1' : etab[i]['Periodes'][0]["Enseigne1"],
        'ActEtab' : etab[i]['Periodes'][0]["LibelleActiviteEtablissement"],
        'CodeActEtab' : etab[i]['Periodes'][0]["ActivitePrincipaleEtablissement"]
        } for i in range(len(etab))]
        
    # Creation d un dataframe pandas
    df = pd.DataFrame(table,index = range(len(etab)))
    return df

requete_api("RENNES",10)