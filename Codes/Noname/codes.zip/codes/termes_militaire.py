
sirus["ident"] = sirus.sirus_id + sirus.nic
check = [word in  liste_siren for word in sirus.ident]

verif = sirus.loc[sirus["ident"].isin(liste_siren)]

cols = verif.sigle
cols = [str(row) for row in cols if row!=numpy.NaN]

c = comptage_mots(cols)