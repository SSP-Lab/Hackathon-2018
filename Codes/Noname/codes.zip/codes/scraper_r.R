
install.packages("rvest")

library(rvest)

page <- html("https://encrypted.google.com/search?hl=fr&q=enseignement+malakoff")

test <- html_nodes(page, xpath="//h3//a[@href]")
xml_text(test)



page <- html("https://www.pagesjaunes.fr/recherche/malakoff/enseignement")

test <- html_nodes(page, xpath="//h2//a[@class='denomination-links pj-link']")
xml_text(test)