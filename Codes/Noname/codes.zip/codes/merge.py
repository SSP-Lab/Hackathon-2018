
# gestion des tables de donnees
import pandas as pd
import numpy as numpy
# tirage aleatoire
import random as rd
# fuzzy matching
#pip install fuzzywuzzy
#pip install python-Levenshtein
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

#-----------------------------------------------------------------------------------------------------------------#
#chargement des donnees du rp
#-----------------------------------------------------------------------------------------------------------------#
import pprint   # For proper print of sequences.
import treetaggerwrapper
#1) build a TreeTagger wrapper:
tagger = treetaggerwrapper.TreeTagger(TAGLANG='fr',TAGDIR='/Users/stephaniehimpens/Documents/teetagger')
 #2) tag your text.


rp = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/rp_final_2014.csv",sep=";",dtype=str)
print("Jeux de données chargé ; " + str(rp.shape[0]) + " lignes, " + str(rp.shape[1]) + " colonnes.")

rp.loc[rp.NUMVOI_X.isnull(),"NUMVOI_X"]=""
rp.loc[rp.BISTER_X.isnull(),"BISTER_X"]=""
rp.loc[rp.TYPEVOI_X.isnull(),"TYPEVOI_X"]=""
rp.loc[rp.NOMVOI_X.isnull(),"NOMVOI_X"]=""
rp.loc[rp.CPLADR_X.isnull(),"CPLADR_X"]=""

rp.NUMVOI_X = [str(int("0" + word)) for word in rp.NUMVOI_X]
rp.loc[rp.NUMVOI_X=='0',"NUMVOI_X"]=''



ADR_FULL = rp.NUMVOI_X + " " + rp.BISTER_X + " " + rp.TYPEVOI_X + " "+ rp.NOMVOI_X + " " + rp.CPLADR_X
sup_blanc = lambda x:x.strip()
ADR_FULL = ADR_FULL.map(sup_blanc)
rp["ADR_FULL"] = ADR_FULL


#print(rp[0:1])
#raison_sociale = rp[0:10]


#tirage aleatoire des donnees du rp
id_ech = numpy.random.choice(range(rp.shape[0]),size=500,replace=False)
rp = rp.iloc[id_ech,]




# Nettoyage des RS du recensement  
# remplacement des codes communes
for index,row in rp.iterrows():
    depcom = str(row.DEPCOM_CODE)
    depcom = str(row.CLT_X) + ' ' + depcom[0:2]
    row.RS_X = re.sub(depcom,'',str(row.RS_X))   
    row.RS_X = re.sub(str(row.CLT_X),'',str(row.RS_X))
    tags = tagger.tag_text(row.RS_X)
    c=''
    for t in range(len(tags)) :
       if t=='' : c = c + " " + str(tags[t]).split('\t')[2]
       c = c.strip()
    if len(c)>0 : row.RS_X = c
    rp.iloc[index,"RS_X"] = row.RS_X
rp.RS_X = [clean_text(word) for word in rp.RS_X]
rp.CLT_X = [clean_text(word) for word in rp.CLT_X]
rp.CLT_X = [re.sub('ST ','SAINT ',word) for word in rp.CLT_X]
rp.CLT_X = [re.sub(r'[0-9]','',word).strip() for word in rp.CLT_X]
rp.CLT_X = [re.sub(r'[0-9]','',word).strip() for word in rp.CLT_X]
rp.CLT_X = [re.sub('NAN','',word).strip() for word in rp.CLT_X]

# Remplacement specifique
rp.RS_X = [re.sub('VILLE','COMMUNE'+str(rp.CLT_X),word) for word in rp.RS_X]
rp.RS_X = [re.sub('MAIRIE','COMMUNE'+str(rp.CLT_X),word) for word in rp.RS_X]
rp.RS_X = [re.sub('LBV YVES ROCHER','YVES ROCHER',word) for word in rp.RS_X]
rp.RS_X = [re.sub('CHU ','HOPITAL',word) for word in rp.RS_X]

educ = ["education national","education","ministere education","ministere","national ecole","inspection education","inspection","ecole","lycee","college","maternelle"]
educ = [word.upper() for word in educ]


# test existence des communes
test = [(len([ok for ok in com_2016.LIBGEO if ok==str(test)])==0) for test in rp.CLT_X]
# correction des codes communes
col=[]
for libelle in rp[test].CLT_X:
    if len(libelle)>0:
        no=process.extractOne(libelle, com_2016.LIBGEO,scorer=fuzz.QRatio)
        print(libelle+' '+no[0])
        col.extend([no[0]])
    else :
        col.extend([""])
rp.ix[test,"CLT_X"]=col

#-----------------------------------------------------------------------------------------------------------------#
#chargement des donnees de siren
#-----------------------------------------------------------------------------------------------------------------#
# 
sirus = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/sirus_2014.csv",sep=";",encoding='latin1',dtype={"sirus_id":str,"nic":str,"ape":str,"apet":str,"eff_3112_et":str,"eff_etp_et":str,"eff_et_effet_daaaammjj":str,"enseigne_et1":str,"nom_comm_et":str,"adr_et_loc_geo":str,"adr_et_compl":str,"adr_et_voie_num":str,"adr_et_voie_repet":str,"adr_et_voie_type":str,"adr_et_voie_lib":str,"adr_et_cedex":str,"adr_et_distsp":str,"sir_adr_et_com_lib":str,"adr_et_post":str,"adr_et_l1":str,"adr_et_l2":str,"adr_et_l3":str,"adr_et_l4":str,"adr_et_l5":str,"adr_et_l6":str,"adr_et_l7":str,"nic_siege":str,"unite_type":str,"region":str,"adr_depcom":str,"region_impl":str,"region_mult":str,"tr_eff_etp":str,"cj":str,"denom":str,"denom_condense":str,"sigle":str,"enseigne":str,"eff_3112_uniteLegale":str,"eff_etp_uniteLegale":str,"eff_effet_daaaammjj_uniteLegale":str,"x":str,"y":str,"SourceXYW":str,"qual":str})
# 
# #mise en forme des donnees sirus
sirus.denom = [clean_text(word) for word in sirus.denom]
sirus.sir_adr_et_com_lib = [clean_text(word) for word in sirus.sir_adr_et_com_lib]
sirus.sir_adr_et_com_lib = sirus.sir_adr_et_com_lib.replace('ST ','SAINT ')
sirus.sir_adr_et_com_lib = sirus.sir_adr_et_com_lib.replace('STE ','SAINTE ')
sirus.sir_adr_et_com_lib = [re.sub(r' CEDEX [0-9]*','',word).strip() for word in sirus.sir_adr_et_com_lib]
sirus.sir_adr_et_com_lib = [re.sub(r'/w','',word).strip() for word in sirus.sir_adr_et_com_lib]


    
#export de la table nettoyee
sirus.to_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/sirus_nettoye.csv",sep=";")

#import de la table nettoyee
sirus = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/sirus_nettoye.csv",sep=";",low_memory=False,encoding='latin1')

#supression des etablissements sans salaries ? 

#from IPython.display import HTML
#vingts_premiers = df[0:20] # on extrait les 20 premières lignes
#HTML(vingts_premiers.to_html())


# matching flou avec les etablissements de sirus
noliste=[]
nb=0

for index,row in rp.iterrows():
    nb=nb+1
    print(nb)
    selection = sirus[sirus.sir_adr_et_com_lib == row.CLT_X]
    selection.denom = [clean_text(word) for word in selection.denom]
    selection.adr_et_post = [clean_text(word) for word in selection.adr_et_post]
    #condens = selection.denom + " "+selection.adr_et_post
    row.RS_X = re.sub(row.CLT_X,'',row.RS_X)
    no=[]
    if selection is None :
        print("Probleme de commune")
    no1=process.extract(row.RS_X, selection.denom,scorer=fuzz.partial_ratio)
    no1 = [(row.CABBI,row.RS_X,rs,score,selection.ix[index,"ident"]) for rs,score,index in no1 if score>80]
    no2=process.extract(row.RS_X, selection.adr_et_post,scorer=fuzz.partial_ratio)
    no2 = [(row.CABBI,row.RS_X,rs,score,selection.ix[index,"ident"]) for rs,score,index in no2 if score>80]
    #no2 = [(row.CABBI,row.RS_X,rs,score,index,fuzz.ratio(row.RS_X,rs)) for rs,score,index in no2 if score>80]
    #no3=process.extract(row.RS_X, selection.enseigne,scorer=fuzz.token_sort_ratio)
    #no3 = [(row.CABBI,row.RS_X,rs,score,index,fuzz.ratio(row.RS_X,rs)) for rs,score,index in no3 if score>80]
    no.extend(no1)
    no.extend(no2)
    #no.extend(no3)
    if len(no)==0:
        no3=[]
        w = False
        for words in row.RS_X:
            if words in educ : w = True
        if w == True :
            for e in educ :
                n=process.extract(e, selection.enseigne_et1,scorer=fuzz.partial_ratio)
                n = [(row.CABBI,row.RS_X,rs,score,selection.ix[index,"ident"]) for rs,score,index in n if score>80]
                if len(n)>0 : no3.extend(n)
        if len(no3)==0 : noliste.extend([(row.CABBI,row.RS_X,"","","")])
        else : noliste.extend(no3)
    else : 
        noliste.extend(no)
    
        
labels = ['CABBI', 'RS_RP','RS_SIRUS', 'SCORE1', 'INDEX']
df = pd.DataFrame.from_records(noliste, columns=labels)
    

df.to_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/codage_rs.csv",sep=";",encoding='latin1')
df = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/codage_rs.csv",sep=";",encoding='latin1')

#sirus["ident2"] = sirus.sirus_id + sirus.nic
mini = sirus.loc[sirus["ident"].isin(df.INDEX)]
#df2 = df
# filtrage sur l adresse 
for index,row in df.iterrows():
    print(index)
    if row.RS_RP!='' and row.RS_SIRUS!='' :
        test_rs = fuzz.token_sort_ratio(row.RS_RP,row.RS_SIRUS)
    else : 
        test_rs=''
    adr_rp = rp.loc[rp.CABBI==row.CABBI,"NOMVOI_X"]
    adr_sir = mini.loc[mini["ident"]==row.INDEX,"adr_et_voie_lib"]
    print(adr_sir)
    test_adr = fuzz.token_sort_ratio(adr_rp,adr_sir)
    print(index)
    df.ix[index,"ADR_RP"]=str(adr_rp)
    df.ix[index,"ADR_SIR"]=str(adr_sir)
    df.ix[index,"SCORE_RS"]=test_rs
    df.ix[index,"SCORE_ADR"]=test_adr
    
df.to_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/codage_rs_v2.csv",sep=";",encoding='latin1')