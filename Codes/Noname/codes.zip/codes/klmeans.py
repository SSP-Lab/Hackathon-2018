from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import Normalizer

don_rp = pd.read_csv('/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/rp_final_2014.csv',delimiter=';',encoding='Latin1',low_memory=False)

documents = [clean_text(word) for word in don_rp.RS_X]


doc = [re.sub('[^A-Z\s]|','',str(words)) for words in documents]
doc = [words.strip() for words in doc]
tokens = [(nltk.word_tokenize(words,language='french')) for words in doc]
clean_tokens = []
for token in tokens:
    clean = []
    for c in token :
        if c.lower() in stopwords.words('french') or c=='A' or c=='NAN':
            clean = clean
        else:
            tags = tagger.tag_text(c)
            if len(tags)>0 : c = str(tags[0]).split('\t')[2]
            clean.append(c)
            #if d.check(c.upper()) : clean.append(c)
            #else : clean.append(d.suggest(c.upper())[0])
    clean = [word.upper() for word in clean]
    #if len(clean)>0 : clean = clean[0]
    clean = " ".join(clean)
    clean_tokens.append(clean)
print(clean_tokens[:100]) 
 
#documents = []
 
# Premiere version

vectorizer = TfidfVectorizer(ngram_range=(1,2))
X =  vectorizer.fit_transform(cols)

from sklearn.metrics.pairwise import cosine_similarity
dist = 1 - cosine_similarity(X)
print
print

 
true_k = 5
model = KMeans(n_clusters=true_k, init='k-means++', max_iter=100, n_init=1)
model.fit(X)

# Latent semantic Analysis
# Nouvel essai
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(clean_tokens)

vectorizer = TfidfTransformer()
X = vectorizer.fit_transform(X_train_counts)

svd = TruncatedSVD(141)
lsa = make_pipeline(svd, Normalizer(copy=False))

X = lsa.fit_transform(X)

km = KMeans(n_clusters=141, init='k-means++', max_iter=100)
km.fit(X)
model=km

print(X.shape)

# Visualisation des clusters
clusters = model.labels_.tolist()
 
print("Top terms per cluster:")
order_centroids = model.cluster_centers_.argsort()[:, ::-1]
terms = vectorizer.get_feature_names()
for i in range(true_k):
    print("Cluster %d:" % i),
    for ind in order_centroids[i, :10]:
        print(' %s' % terms[ind]),
    print
 
 
print("\n")
print("Prediction")
 
Y = vectorizer.transform(["chrome browser to open."])
prediction = model.predict(Y)
print(prediction)
 
Y = vectorizer.transform(["My cat is hungry."])
prediction = model.predict(Y)
print(prediction)
 