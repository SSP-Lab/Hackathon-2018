
import pip
#pip install pyenchant
#pip install unidecode

import enchant
import unidecode
import pandas as pd

# Correction orthographique

d = enchant.Dict("fr_FR")

# verification orthographique
d.check("Teste")

d.suggest('ticane')

# dictionnaire personnel
d = enchant.request_pwl_dict("/Users/stephaniehimpens/Documents/Hackathon/donnees/dico.txt")

# Test des communes 

# import des communes
com_2016 = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/data_IlleEtVilaine/liste_commune_2016.csv",sep=";",low_memory=False,encoding='mac_roman')

com_2016.LIBGEO = [clean_text(word) for word in com_2016.LIBGEO]

com_2016.to_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/data_IlleEtVilaine/liste_commune_2016_net.csv",sep=";",encoding='latin1')

test = rp.ix[id_ech[0],"CLT_X"]


# Nouvelle tentative
dico_fr = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/morphalou.csv",sep=",",encoding='mac_roman')
dico = [word for word in dico_fr.orthography2]

dico_fr.orthography2.to_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/dico.csv",sep=";",encoding='latin1',index=False)

c.check('OTAGE')

# synonyme

dico_sy = pd.read_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/synonymes.csv",sep=",",encoding='Latin1')