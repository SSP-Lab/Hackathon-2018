import pandas as pd
import requests
from pprint import pprint
import json
import re
import nltk
import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import Normalizer
from sklearn.feature_extraction.text import TfidfVectorizer

import pprint   # For proper print of sequences.
import treetaggerwrapper
#1) build a TreeTagger wrapper:
tagger = treetaggerwrapper.TreeTagger(TAGLANG='fr',TAGDIR='/Users/stephaniehimpens/Documents/teetagger')
 #2) tag your text.



#Import des donnees du RP
don_rp = pd.read_csv('/Users/stephaniehimpens/Documents/Hackathon/donnees/Donnees/rp_final_2014.csv',delimiter=';',encoding='Latin1',low_memory=False)


# Nettoyage des RS du recensement  
don_rp.ACTET_X = [clean_text(word) for word in don_rp.ACTET_X]

# Mise en forme des mots
ACTET_X = [re.sub('[^A-Z\s]|','',str(words)) for words in don_rp.ACTET_X]
ACTET_X = [words.strip() for words in ACTET_X]
# Jetons en langue francaise
tokens = [(nltk.word_tokenize(words,language='french')) for words in ACTET_X]
clean_tokens = []
for token in tokens:
    clean = []
    for c in token :
        if c.lower() in stopwords.words('french') or c=='A' or c=='NAN':
            clean = clean
        else:
            tags = tagger.tag_text(c)
            if len(tags)>0 : c = str(tags[0]).split('\t')[2]
            if d.check(c.upper()) : clean.append(c)
            # partie de recherche dans le dictionnaire trop longue => desactivee
            #else : 
             #   sug = d.suggest(c.upper())
                #if len(sug)>0 : 
                 #   clean.append(sug[0]) 
                #else : clean.append(c)
    clean = [word.upper() for word in clean]
    #if len(clean)>0 : clean = clean[0]
    clean = " ".join(clean)
    clean_tokens.append(clean)
print(clean_tokens[:100])    
    
#from nltk.stem import SnowballStemmer
#snowball_stemmer = SnowballStemmer("french")
#clean = [snowball_stemmer.stem(word).upper() for word in clean_tokens]

comp = comptage_mots(clean_tokens)
comp = [word for word,nb in comp if nb>4]

test = don_rp
test.ACTET_X = [str(word) for word in clean_tokens]
test = test.loc[test.ACTET_X.isnull()==False]
test = test.loc[test.ACTET_X!='']
test = test.loc[test.ACTET_C.isnull()==False]


categ = [str(ligne)[0:2] for ligne in test.ACTET_C]

test = test.loc[[len(text)>1 for text in categ]]
categ = [text for text in categ if len(text)>1]


# Tirage d un echantillon

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(test['ACTET_X'], categ)



# Classification multinomial NB (non utilise)

from sklearn.naive_bayes import MultinomialNB
clf = MultinomialNB().fit(X_train_tfidf, y_train)
predicted_mult = clf.predict(X_test)
np.mean(predicted_mult == y_test)



predicted = clf.predict(X_test)
np.mean(predicted == y_test)


# Classification SVM

text_clf_svm = Pipeline([('vect', CountVectorizer()),
              ('tfidf', TfidfTransformer()),
                    ('clf-svm', SGDClassifier(loss='hinge', penalty='l2',
                                       alpha=1e-3, n_iter=10, random_state=42)),
 ])
 

_ = text_clf_svm.fit(X_train, y_train)

predicted_svm = text_clf_svm.predict(X_test)
print(np.mean([predicted_svm == y_test]))


from sklearn import metrics
print(metrics.classification_report(y_test, predicted_svm,
target_names=set(y_test)))

from sklearn.model_selection import GridSearchCV
parameters_svm = {'vect__ngram_range': [(1, 1), (1, 2)],
              'tfidf__use_idf': (True, False),
               'clf-svm__alpha': (1e-2, 1e-3),
}
gs_clf_svm = GridSearchCV(text_clf_svm, parameters_svm, n_jobs=-1)
gs_clf_svm = gs_clf_svm.fit(X_train, y_train)
gs_clf_svm.best_score_
gs_clf_svm.best_params_