import pprint   # For proper print of sequences.
import treetaggerwrapper
#1) build a TreeTagger wrapper:
tagger = treetaggerwrapper.TreeTagger(TAGLANG='fr',TAGDIR='/Users/stephaniehimpens/Documents/teetagger')
 #2) tag your text.
tags = tagger.tag_text("COMMERCE GDE DISTRIBUTION")
#3) use the tags list... (list of string output from TreeTagger).
pprint.pprint(tags)
