#Importation des librairies requises

import re
import string as txt
import nltk
from nltk.stem.snowball import FrenchStemmer #import the French stemming library
from nltk.corpus import stopwords #import stopwords from nltk corpus
import operator
import unidecode

#Une fonction de nettoyage de texte

def clean_text(string):
    string = str(string)
    # suppression des accents
    string = unidecode.unidecode(string)
    # Remplace les signes de ponctuations
    for c in txt.punctuation :
        string = re.sub(re.escape(c),' ',string)
    string = string.strip()
    # remplacement des sigles
    s = re.findall(r'\s(\w\s\w)\s',string)
    if len(s)>0 : string = re.sub(' '+s[0]+' ',re.sub(' ','',s[0]),string)
    # Mise en majuscules
    string = string.upper()
    # Suppression des espaces inutiles
    string = string.strip()  
    # Remplace les tabluations, sauts de lignes, etc. par des espaces.
    string = re.sub('\n|\r|\t|\xa0', ' ', string)
    # Retire les ' .' (séparateurs utilisés dans `soup.get_text`) inappropriés.
    string = re.sub('^\.', '', string.replace(' .', ''))
    # Retire les espaces inappropriés.
    return string

# Une fonction de comptage du nombre d occurence d un mot

def comptage_mots(colonne):
    
    # concatenation de la colonne 
    words = " ".join(colonne)
    # Nettoyage sommaire des donnees textuelles
    words = re.sub('\n','',words)
    words = re.sub('[^A-Z\s]|','',words)
    words = words.strip()
    tokens = nltk.word_tokenize(words,language='french')

    # Nettoyage de la chaine de caracteres des stopwords
    clean_tokens = tokens[:]
    for token in tokens:
        if token.lower() in stopwords.words('french'):
            clean_tokens.remove(token)
    # Affichage pour verification
    print(clean_tokens[:100])    

    # Comptage du nombre de mots
    fidist2 = nltk.FreqDist(clean_tokens)

    # tri des mots les plus frequents
    fidist2 = sorted(fidist2.items(), reverse=True, key=operator.itemgetter(1))
    
    return fidist2

    # affichage des lignes les contenant
    for row in colonne:
        if re.search(fidist2[0][0],row) :
            print(row)
            
