# Installation des librairies tierces utilisées.
import pip
for pkg in ['requests', 'bs4']:
    pip.main(['install', pkg])
from bs4 import BeautifulSoup
import requests
import re
import time


testsorted = []
selection = rp.loc[rp.ADR_FULL=='']
selection = selection[:6]


#idee : rechercher les noms de communes dans les autres champs

for index,row in selection.iterrows():
    # Mise en forme de la requete
    if row.CLT_X=='':
        if str(row.DLT_X)=='nan':
            test = 'https://www.pagesjaunes.fr/recherche/'+str(row.DEPCOM_CODE[:2])+'/'+row.RS_X
        else :
            test = 'https://www.pagesjaunes.fr/recherche/'+str(row.DLT_X)+'/'+row.RS_X
    else :
        test = 'https://www.pagesjaunes.fr/recherche/'+str(row.CLT_X)+'/'+str(row.RS_X)
    test = str(test)
    test = re.sub("\[","",test)
    test = re.sub("\]","",test)
    test = re.sub("'","",test)
    test = re.sub('"','',test)
    
    # Interrogation des pages jaunes
    response = requests.get(test)
    text = re.sub('denomination-links pj-link','denomination-links pj-lb pj-link',response.text)
    print(response.status_code)
    if response.status_code != 200:
        print('Échec de la requête: statut %s.' % response.status_code)

    # Mise en forme des donnees textuelles
    soup = BeautifulSoup(text, 'html.parser')
    rsp=[]
    adrp=[]
    actp=[]
    supp=[]
    for p in soup.find_all('article'):
        a = p.find_all('a',{'class','denomination-links pj-lb pj-link'})
        if len(a)==0:
            a=BeautifulSoup("<a> </a>", 'html.parser')
        rsp.extend(a)
        a = p.find_all('a',{'class','adresse pj-lb pj-link'})
        if len(a)==0:
            a=BeautifulSoup("<a> </a>", 'html.parser')
        adrp.extend(a)
        a = p.find_all('a',{'class','activites pj-lb pj-link'})
        if len(a)==0:
            a=BeautifulSoup("<a> </a>", 'html.parser')
        actp.extend(a)
        a = p.find_all('span',{'class','denoms-suppl'})
        if len(a)==0:
            a=BeautifulSoup("<a> </a>", 'html.parser')
        supp.extend(a)
    
    if len(rsp)>0:
        rs = [clean_text(r.text) for r in rsp]
        adresse = [clean_text(r.text) for r in adrp]
        activite = [clean_text(r.text) for r in actp]
        if supp is not None:
            s = [clean_text(su.text) for su in supp]
            s = [re.sub('CONNU SOUS ','',su) for su in s]
        else:    
            s = [""]
    else:
        rs = [""]
        adresse = [""]
        activite = [""]
        s=[""]
        
    test2 = [(row.CABBI,rs[i],adresse[i],activite[i],s[i]) for i in range(min(len(rs),3))]
    print(test2)
    if len(test2)==0 :
        test2 = [(row.CABBI,'','','','')]
    # tri des mots les plus frequents
    if len(testsorted)==0:
        testsorted = test2
    else :
        testsorted.extend(test2)
    
    # arret 5 minutes afin de simuler le comportement d un humain
    time.sleep(5)
    

labels = ['CABBI', 'RS_PJ','ADR_PJ', 'ACT_PJ', 'SP_PJ']
df = pd.DataFrame.from_records(testsorted, columns=labels)
    

#etapes de verification
rp.to_csv("/Users/stephaniehimpens/Documents/Hackathon/donnees/data_IlleEtVilaine/rp_enrichi.csv",sep=";")
